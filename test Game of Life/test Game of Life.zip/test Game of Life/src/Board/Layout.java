package Board;

import javax.swing.*;
import java.awt.*;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Layout extends JFrame//  implements DocumentListener
{
    public int row;
    public int col;
    public double _prob;
    public ButtonColors b = new ButtonColors();
    public String theme;
    public boolean [][] lightArr;
    public JButton[][] button;
    public JButton getButton (int r, int c){
        return button[r][c];
    }
    public int gameCnt = 0;


    public Layout (int _askR, int _askC, String _theme, double probability){
        row = _askR;
        col = _askC;
        _prob = probability;
        theme = _theme;
        button = new JButton[row][col];
        lightArr = new boolean [row][col];

        JPanel panel = new JPanel(new GridLayout(row, col));
        panel.setSize(650,650);
        getContentPane().add(panel, BorderLayout.WEST);

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                button[i][j] = new JButton();
                JButton b = button[i][j];
                makeButton(button[i][j], i, j);
                panel.add(button[i][j]);
            }
        }
        gameCnt++;

        this.setTitle("Tree Simulation"); // Setting the title of board
        getContentPane().setLayout(new BorderLayout());
        this.setSize(650, 680); // Size of the chess board
        this.setVisible(true); // Sets the board visible
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // If you close the window, the program will terminate
        this.setResizable(true); //The window is not resizable anymore ;)
    }



    public void makeButton ( JButton b, int r, int c){
        if (getChance()){
            setButtonOn(b,r,c);
        }
        else {
            setButtonOff(b,r,c);
       }
    }

    public void setButtonOn (JButton ba, int ra, int ca){
        ba.setOpaque(true);
        ba.setBorderPainted(false);
        b.setButtonColor(theme, ba);
        lightArr[ra][ca] = true;
    }

    public void setButtonOff (JButton ba, int ra, int ca){
        ba.setOpaque(true);
        ba.setBorderPainted(false);
        ba.setBackground(new java.awt.Color(0, 0, 0));
        lightArr[ra][ca] = false;
    }

    public boolean getChance (){
        return Math.random() < _prob;
    }



}
